import org.hamcrest.*;

public class LongitudCadenaMatcher extends FeatureMatcher<String, Integer> {
    private final int longitudEsperada;

    public LongitudCadenaMatcher(int longitudEsperada) {
        super(CoreMatchers.equalTo(longitudEsperada), "una cadena con longitud", "longitud diferente");
        this.longitudEsperada = longitudEsperada;
    }

    @Override
    protected Integer featureValueOf(String actual) {
        return actual.length();
    }
}