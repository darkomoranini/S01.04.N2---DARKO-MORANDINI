import org.hamcrest.*;
import org.junit.Test;

public class EjemploTest {

    @Test
    public void testLongitudCadena() {
        String cadena = "Mordor";
        MatcherAssert.assertThat(cadena, new LongitudCadenaMatcher(6));
    }
}